const { Client } = require('pg');
const PostController = require('./Controllers/PostController')

let DATABASE_CREDIDENTIALS = {
  ENDPOINT: process.env.DB_HOST,
  NAME: process.env.DB_NAME,
  USERNAME: process.env.DB_USER,
  PASSWORD: process.env.DB_PASS
};


const client = new Client({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASS,
  port: 5432
});

let connectToDatabase = async (callback) => {
  try {
    await client.connect();
    callback(null, "Connected Successfully");
    //your code here

  } catch (err) {

    callback(null, "Failed to Connect Successfully");
    throw err;
    //error message
  }

  client.end();
}


exports.hello = async (event) => {

  await connectToDatabase((err, data) => {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({message: data})
    }
  });


}