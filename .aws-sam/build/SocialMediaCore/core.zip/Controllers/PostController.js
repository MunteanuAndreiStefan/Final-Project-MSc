exports.data = {
    returnMessage: 'Authenticated call! - Works'
}